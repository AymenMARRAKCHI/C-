/********************************************************************************
** Form generated from reading UI file 'AjoutBorneStationnement.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTBORNESTATIONNEMENT_H
#define UI_AJOUTBORNESTATIONNEMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AjoutBorneStationnement
{
public:
    QLabel *label;
    QLineEdit *IdVoiePublique;
    QLineEdit *Latitude;
    QLabel *label_4;
    QLineEdit *IdBorne;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_5;
    QLineEdit *NomTopo;
    QLineEdit *Longitude;
    QLabel *label_6;
    QLineEdit *NumStatio;
    QLabel *label_7;
    QLineEdit *CoteRue;
    QPushButton *Ok;

    void setupUi(QDialog *AjoutBorneStationnement)
    {
        if (AjoutBorneStationnement->objectName().isEmpty())
            AjoutBorneStationnement->setObjectName(QString::fromUtf8("AjoutBorneStationnement"));
        AjoutBorneStationnement->resize(659, 600);
        label = new QLabel(AjoutBorneStationnement);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 100, 151, 16));
        IdVoiePublique = new QLineEdit(AjoutBorneStationnement);
        IdVoiePublique->setObjectName(QString::fromUtf8("IdVoiePublique"));
        IdVoiePublique->setGeometry(QRect(330, 150, 271, 28));
        Latitude = new QLineEdit(AjoutBorneStationnement);
        Latitude->setObjectName(QString::fromUtf8("Latitude"));
        Latitude->setGeometry(QRect(330, 270, 271, 28));
        label_4 = new QLabel(AjoutBorneStationnement);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(100, 280, 91, 16));
        IdBorne = new QLineEdit(AjoutBorneStationnement);
        IdBorne->setObjectName(QString::fromUtf8("IdBorne"));
        IdBorne->setGeometry(QRect(330, 90, 271, 28));
        label_2 = new QLabel(AjoutBorneStationnement);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(100, 160, 171, 16));
        label_3 = new QLabel(AjoutBorneStationnement);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(100, 220, 161, 16));
        label_5 = new QLabel(AjoutBorneStationnement);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(100, 340, 121, 16));
        NomTopo = new QLineEdit(AjoutBorneStationnement);
        NomTopo->setObjectName(QString::fromUtf8("NomTopo"));
        NomTopo->setGeometry(QRect(330, 210, 271, 28));
        Longitude = new QLineEdit(AjoutBorneStationnement);
        Longitude->setObjectName(QString::fromUtf8("Longitude"));
        Longitude->setGeometry(QRect(330, 330, 271, 28));
        label_6 = new QLabel(AjoutBorneStationnement);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(100, 380, 231, 51));
        NumStatio = new QLineEdit(AjoutBorneStationnement);
        NumStatio->setObjectName(QString::fromUtf8("NumStatio"));
        NumStatio->setGeometry(QRect(330, 390, 271, 28));
        label_7 = new QLabel(AjoutBorneStationnement);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(100, 450, 81, 16));
        CoteRue = new QLineEdit(AjoutBorneStationnement);
        CoteRue->setObjectName(QString::fromUtf8("CoteRue"));
        CoteRue->setGeometry(QRect(330, 440, 81, 28));
        Ok = new QPushButton(AjoutBorneStationnement);
        Ok->setObjectName(QString::fromUtf8("Ok"));
        Ok->setGeometry(QRect(520, 530, 90, 28));

        retranslateUi(AjoutBorneStationnement);
        QObject::connect(Ok, SIGNAL(clicked()), AjoutBorneStationnement, SLOT(valider()));

        QMetaObject::connectSlotsByName(AjoutBorneStationnement);
    } // setupUi

    void retranslateUi(QDialog *AjoutBorneStationnement)
    {
        AjoutBorneStationnement->setWindowTitle(QCoreApplication::translate("AjoutBorneStationnement", "AjoutBorneStationnement", nullptr));
        label->setText(QCoreApplication::translate("AjoutBorneStationnement", "Identifiant  de la borne :", nullptr));
        label_4->setText(QCoreApplication::translate("AjoutBorneStationnement", "Latitude :", nullptr));
        label_2->setText(QCoreApplication::translate("AjoutBorneStationnement", "Identifiant Voie Publique : ", nullptr));
        label_3->setText(QCoreApplication::translate("AjoutBorneStationnement", "Nom Topographique : ", nullptr));
        label_5->setText(QCoreApplication::translate("AjoutBorneStationnement", "Longitude :", nullptr));
        label_6->setText(QCoreApplication::translate("AjoutBorneStationnement", "Num\303\251ro de la borne Stationnement : ", nullptr));
        label_7->setText(QCoreApplication::translate("AjoutBorneStationnement", "Cote Rue:", nullptr));
        Ok->setText(QCoreApplication::translate("AjoutBorneStationnement", "Cr\303\251er", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AjoutBorneStationnement: public Ui_AjoutBorneStationnement {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTBORNESTATIONNEMENT_H
