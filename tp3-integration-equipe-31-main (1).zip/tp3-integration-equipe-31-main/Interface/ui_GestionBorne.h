/********************************************************************************
** Form generated from reading UI file 'GestionBorne.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESTIONBORNE_H
#define UI_GESTIONBORNE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GestionBorne
{
public:
    QAction *actionSupprimer_une_Borne;
    QAction *actionQuitter;
    QAction *actionBorne_Fontaine;
    QAction *actionBorne_Stationnement;
    QWidget *centralwidget;
    QTextEdit *affichage;
    QMenuBar *menubar;
    QMenu *menuMenu;
    QMenu *menuAjouter_une_Borne;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *GestionBorne)
    {
        if (GestionBorne->objectName().isEmpty())
            GestionBorne->setObjectName(QString::fromUtf8("GestionBorne"));
        GestionBorne->resize(800, 600);
        actionSupprimer_une_Borne = new QAction(GestionBorne);
        actionSupprimer_une_Borne->setObjectName(QString::fromUtf8("actionSupprimer_une_Borne"));
        actionQuitter = new QAction(GestionBorne);
        actionQuitter->setObjectName(QString::fromUtf8("actionQuitter"));
        actionBorne_Fontaine = new QAction(GestionBorne);
        actionBorne_Fontaine->setObjectName(QString::fromUtf8("actionBorne_Fontaine"));
        actionBorne_Stationnement = new QAction(GestionBorne);
        actionBorne_Stationnement->setObjectName(QString::fromUtf8("actionBorne_Stationnement"));
        centralwidget = new QWidget(GestionBorne);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        affichage = new QTextEdit(centralwidget);
        affichage->setObjectName(QString::fromUtf8("affichage"));
        affichage->setGeometry(QRect(20, 20, 691, 511));
        GestionBorne->setCentralWidget(centralwidget);
        menubar = new QMenuBar(GestionBorne);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        menuMenu = new QMenu(menubar);
        menuMenu->setObjectName(QString::fromUtf8("menuMenu"));
        menuAjouter_une_Borne = new QMenu(menuMenu);
        menuAjouter_une_Borne->setObjectName(QString::fromUtf8("menuAjouter_une_Borne"));
        GestionBorne->setMenuBar(menubar);
        statusbar = new QStatusBar(GestionBorne);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        GestionBorne->setStatusBar(statusbar);

        menubar->addAction(menuMenu->menuAction());
        menuMenu->addAction(menuAjouter_une_Borne->menuAction());
        menuMenu->addAction(actionSupprimer_une_Borne);
        menuMenu->addAction(actionQuitter);
        menuAjouter_une_Borne->addAction(actionBorne_Fontaine);
        menuAjouter_une_Borne->addAction(actionBorne_Stationnement);

        retranslateUi(GestionBorne);
        QObject::connect(actionQuitter, SIGNAL(triggered()), GestionBorne, SLOT(close()));
        QObject::connect(actionBorne_Fontaine, SIGNAL(triggered()), GestionBorne, SLOT(dialogFontaine()));
        QObject::connect(actionBorne_Stationnement, SIGNAL(triggered()), GestionBorne, SLOT(dialogStationnement()));
        QObject::connect(actionSupprimer_une_Borne, SIGNAL(triggered()), GestionBorne, SLOT(dialogSupprimer()));

        QMetaObject::connectSlotsByName(GestionBorne);
    } // setupUi

    void retranslateUi(QMainWindow *GestionBorne)
    {
        GestionBorne->setWindowTitle(QCoreApplication::translate("GestionBorne", "GestionBorne", nullptr));
        actionSupprimer_une_Borne->setText(QCoreApplication::translate("GestionBorne", "Supprimer une Borne", nullptr));
        actionQuitter->setText(QCoreApplication::translate("GestionBorne", "Quitter", nullptr));
        actionBorne_Fontaine->setText(QCoreApplication::translate("GestionBorne", "Borne Fontaine", nullptr));
        actionBorne_Stationnement->setText(QCoreApplication::translate("GestionBorne", "Borne Stationnement", nullptr));
        menuMenu->setTitle(QCoreApplication::translate("GestionBorne", "Menu", nullptr));
        menuAjouter_une_Borne->setTitle(QCoreApplication::translate("GestionBorne", "Ajouter une Borne", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GestionBorne: public Ui_GestionBorne {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESTIONBORNE_H
