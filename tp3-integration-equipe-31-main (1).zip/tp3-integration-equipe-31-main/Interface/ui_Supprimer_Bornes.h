/********************************************************************************
** Form generated from reading UI file 'Supprimer_Bornes.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPPRIMER_BORNES_H
#define UI_SUPPRIMER_BORNES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Supprimer_Bornes
{
public:
    QLabel *label;
    QLineEdit *IdBorne;
    QPushButton *Supprimer;

    void setupUi(QDialog *Supprimer_Bornes)
    {
        if (Supprimer_Bornes->objectName().isEmpty())
            Supprimer_Bornes->setObjectName(QString::fromUtf8("Supprimer_Bornes"));
        Supprimer_Bornes->resize(427, 260);
        label = new QLabel(Supprimer_Bornes);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 100, 151, 16));
        IdBorne = new QLineEdit(Supprimer_Bornes);
        IdBorne->setObjectName(QString::fromUtf8("IdBorne"));
        IdBorne->setGeometry(QRect(200, 90, 171, 28));
        Supprimer = new QPushButton(Supprimer_Bornes);
        Supprimer->setObjectName(QString::fromUtf8("Supprimer"));
        Supprimer->setGeometry(QRect(160, 180, 90, 28));

        retranslateUi(Supprimer_Bornes);
        QObject::connect(Supprimer, SIGNAL(clicked()), Supprimer_Bornes, SLOT(Supprime()));

        QMetaObject::connectSlotsByName(Supprimer_Bornes);
    } // setupUi

    void retranslateUi(QDialog *Supprimer_Bornes)
    {
        Supprimer_Bornes->setWindowTitle(QCoreApplication::translate("Supprimer_Bornes", "Supprimer_Bornes", nullptr));
        label->setText(QCoreApplication::translate("Supprimer_Bornes", "Identifiant de la borne : ", nullptr));
        Supprimer->setText(QCoreApplication::translate("Supprimer_Bornes", "Supprimer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Supprimer_Bornes: public Ui_Supprimer_Bornes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPPRIMER_BORNES_H
