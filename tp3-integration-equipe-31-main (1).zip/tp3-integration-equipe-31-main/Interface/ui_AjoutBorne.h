/********************************************************************************
** Form generated from reading UI file 'AjoutBorne.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTBORNE_H
#define UI_AJOUTBORNE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AjoutBorne
{
public:
    QLabel *label;
    QLineEdit *IdBorne;
    QLabel *label_2;
    QLineEdit *IdVoiePublique;
    QLabel *label_3;
    QLineEdit *NomTopo;
    QLabel *label_4;
    QLineEdit *Latitude;
    QLabel *label_5;
    QLineEdit *Longitude;
    QLabel *label_6;
    QLineEdit *Ville;
    QLabel *label_7;
    QLineEdit *Arrondissement;
    QPushButton *ok;

    void setupUi(QDialog *AjoutBorne)
    {
        if (AjoutBorne->objectName().isEmpty())
            AjoutBorne->setObjectName(QString::fromUtf8("AjoutBorne"));
        AjoutBorne->resize(740, 576);
        label = new QLabel(AjoutBorne);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(140, 70, 151, 16));
        IdBorne = new QLineEdit(AjoutBorne);
        IdBorne->setObjectName(QString::fromUtf8("IdBorne"));
        IdBorne->setGeometry(QRect(330, 60, 271, 28));
        label_2 = new QLabel(AjoutBorne);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(140, 130, 171, 16));
        IdVoiePublique = new QLineEdit(AjoutBorne);
        IdVoiePublique->setObjectName(QString::fromUtf8("IdVoiePublique"));
        IdVoiePublique->setGeometry(QRect(330, 120, 271, 28));
        label_3 = new QLabel(AjoutBorne);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(140, 190, 161, 16));
        NomTopo = new QLineEdit(AjoutBorne);
        NomTopo->setObjectName(QString::fromUtf8("NomTopo"));
        NomTopo->setGeometry(QRect(330, 180, 271, 28));
        label_4 = new QLabel(AjoutBorne);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(140, 250, 91, 16));
        Latitude = new QLineEdit(AjoutBorne);
        Latitude->setObjectName(QString::fromUtf8("Latitude"));
        Latitude->setGeometry(QRect(330, 240, 271, 28));
        label_5 = new QLabel(AjoutBorne);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(140, 310, 121, 16));
        Longitude = new QLineEdit(AjoutBorne);
        Longitude->setObjectName(QString::fromUtf8("Longitude"));
        Longitude->setGeometry(QRect(330, 300, 271, 28));
        label_6 = new QLabel(AjoutBorne);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(150, 380, 58, 16));
        Ville = new QLineEdit(AjoutBorne);
        Ville->setObjectName(QString::fromUtf8("Ville"));
        Ville->setGeometry(QRect(330, 370, 271, 28));
        label_7 = new QLabel(AjoutBorne);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(140, 450, 161, 16));
        Arrondissement = new QLineEdit(AjoutBorne);
        Arrondissement->setObjectName(QString::fromUtf8("Arrondissement"));
        Arrondissement->setGeometry(QRect(330, 440, 271, 28));
        ok = new QPushButton(AjoutBorne);
        ok->setObjectName(QString::fromUtf8("ok"));
        ok->setGeometry(QRect(570, 510, 90, 28));

        retranslateUi(AjoutBorne);
        QObject::connect(ok, SIGNAL(clicked()), AjoutBorne, SLOT(valider()));

        QMetaObject::connectSlotsByName(AjoutBorne);
    } // setupUi

    void retranslateUi(QDialog *AjoutBorne)
    {
        AjoutBorne->setWindowTitle(QCoreApplication::translate("AjoutBorne", "AjoutBorne", nullptr));
        label->setText(QCoreApplication::translate("AjoutBorne", "Identifiant  de la borne :", nullptr));
        label_2->setText(QCoreApplication::translate("AjoutBorne", "Identifiant Voie Publique : ", nullptr));
        label_3->setText(QCoreApplication::translate("AjoutBorne", "Nom Topographique : ", nullptr));
        label_4->setText(QCoreApplication::translate("AjoutBorne", "Latitude :", nullptr));
        label_5->setText(QCoreApplication::translate("AjoutBorne", "Longitude :", nullptr));
        label_6->setText(QCoreApplication::translate("AjoutBorne", "Ville :", nullptr));
        label_7->setText(QCoreApplication::translate("AjoutBorne", "Arrondissement :", nullptr));
        ok->setText(QCoreApplication::translate("AjoutBorne", "Cr\303\251er", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AjoutBorne: public Ui_AjoutBorne {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTBORNE_H
