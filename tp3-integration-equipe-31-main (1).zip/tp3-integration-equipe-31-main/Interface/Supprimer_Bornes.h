/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/qtFiles/form.h to edit this template
 */

/* 
 * File:   Supprimer_Bornes.h
 * Author: etudiant
 *
 * Created on 24 avril 2024, 23 h 45
 */

#ifndef _SUPPRIMER_BORNES_H
#define _SUPPRIMER_BORNES_H

#include "ui_Supprimer_Bornes.h"

class Supprimer_Bornes : public QDialog
{
  Q_OBJECT
public:
  Supprimer_Bornes ();
  virtual ~Supprimer_Bornes ();
  QString reqIdentifiantBorne()const ;
  private slots : 
    void Supprime();
private:
  Ui::Supprimer_Bornes widget;
};

#endif /* _SUPPRIMER_BORNES_H */
